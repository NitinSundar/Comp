#include<stdio.h>
void rev(char* begin, char *end)
{
    char temp;
    while(begin<end)
    {
        temp=*begin;
        *begin++=*end;
        *end--=temp;
    }
}
void ans(char *s)
{
    char *begin=s;
    char*temp=s;
    while(*temp)
    {
        temp++;
        if(*temp=='\0')
        {
            rev(begin,temp-1);
        }
        else if(*temp==' ')
        {
            rev(begin,temp-1);
            begin=temp+1;
        }
    }
    rev(s,temp-1);
}
int main()
{
    char arr[500];
    scanf("%[^\n]s",arr);
    ans(arr);
    printf("%s",arr);
    return 0;
}
