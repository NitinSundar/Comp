#include<stdio.h>
#include<stdlib.h>

int cmp (const void * x, const void * y)
{
    if( *(long long int*)x - *(long long int*)y < 0 )
        return -1;
    if( *(long long int*)x - *(long long int*)y > 0 )
        return 1;
    if( *(long long int*)x - *(long long int*)y == 0 )
        return 0;
}

int main()
{
    int t;
    scanf("%d",&t);
    int z;
    for(z=0;z<t;z++)
    {
        long long int n,k;
        scanf("%lld %lld",&n,&k);
        long long int a[n];

        int i;
        for(i=0;i<n;i++)
            scanf("%lld",&a[i]);

        qsort(a,n,sizeof(long long int),cmp);

        long long int lo=0,hi=1e18,ans=-1;

        while(lo<hi)
        {
            long long int mid=(lo+hi)/2;

            long long int last_pos=a[0],ppl=1,flag=0;

            for(i=1;i<n;i++)
            {
                if(a[i]-last_pos>=mid)
                {
                    ppl++;

                    if(ppl==k)
                    {
                        flag=1;
                        break;
                    }
                    last_pos=a[i];
                }
            }

            if(flag==1) lo=mid+1,ans=mid;
            else hi=mid;
        }
        printf("%d\n",ans);
    }
    return 0;
}
