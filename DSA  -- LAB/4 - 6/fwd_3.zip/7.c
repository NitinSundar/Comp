#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void reverse(char* x, char *y)
{
    char temp;
    while(x<y){
        temp=*x;
        *x++=*y;
        *y--=temp;
    }
}

int main()
{
    int t;
    scanf("%d",&t);
    int z;
    for(z=0;z<t;z++)
    {
        int i;
        char s[500];
        scanf("%s",s);
        int l=strlen(s);
        int a=-1;
        for(i=l-2;i>=0;i--)
        {
            if(s[i]<s[i+1])
            {
                a=i;
                break;
            }
        }
        if(a==-1)
        {
            printf("game terminated!\n");
            continue;
        }
        for(i=l-1;i>=a+1;i--)
        {
            if(s[i]>s[a])
            {
                char t;
                t=s[a];
                s[a]=s[i];
                s[i]=t;
                break;
            }
        }
        reverse(&s[a+1],&s[l-1]);
        printf("%s\n",s);
    }
    return 0;
}
