#include<stdio.h>
#include<stdlib.h>
int cmpfnc(const void *a,const void *b){
    return(*(int *)a-*(int *)b);
}
int bs(int *arr, int l, int r, int x){
    if(r>=l){
        int mid=l+(r-l)/2;
        if(arr[mid]==x)
            return mid;
        if(arr[mid]>x)
            return bs(arr,1,mid-1,x);
        return bs(arr,mid+1,r,x);
    }
    return -1;
}
int main(){
    int n,x,flag=0;
    scanf("%d %d",&n,&x);
    int *arr=(int *)malloc(sizeof(int)*n);
    int i;
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    qsort(arr,n,sizeof(int),cmpfnc);
    int ans;
    for(i=0;i<n;i++){
        ans=bs(arr,0,n-1,x-arr[i]);
        if(ans!=-1){
            flag=1;
            break;
        }
    }
    if(flag==1){
        printf("Yes\n");
    }
    else{
        printf("No\n");
    }
    return 0;
}
