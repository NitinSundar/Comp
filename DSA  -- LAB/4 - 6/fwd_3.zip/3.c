#include<stdio.h>
#include<string.h>

int main()
{
    int n;
    scanf("%d",&n);
    int i;
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    int lo=0,hi=n-1,ans=0;
    while(lo<=hi)
    {
        int mid=(lo+hi)/2;
        if((mid==0 || a[mid]>=a[mid-1])&&( mid==n-1 || a[mid]>=a[mid+1]))
        {
            ans=mid;
            break;
        }
        else if(a[mid]<a[mid+1] && mid>0)
            lo=mid+1;
        else hi=mid-1;
    }
    printf("%d\n",ans);
    return 0;
}
