#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int tsearch(int *data, int left, int right, int value){
    int i;
    int first,second;
    if(left>right)
       return -1;

    i= (right - left)/3;
    if(i==0) i++;

    first = i  + left -1;
    second = i*2 + left - 1;

    if(data[first]==value)
       return first;
    else
    if(data[first]>value)
         return tsearch(data, left, first-1, value);
    else{
        if(data[second]==value)
          return second;
        else
        if(data[second]>value)
           return tsearch(data, first+1,second-1, value);
        else
           return tsearch(data, second+1,right, value);
     }
}
int bs(int *arr, int l, int r, int x){
    if(r>=l){
        int mid=l+(r-l)/2;
        if(arr[mid]==x){
            return mid;
        }
        if(arr[mid]>x)
            return bs(arr,l,mid-1,x);
        return bs(arr,mid+1,r,x);
    }
    return -1;
}
int main(){
    clock_t s1,e1,s2,e2;
    time_t t;
    srand((unsigned)time(&t));
    int n,k,i;
    scanf("%d %d",&n, &k);
    int *arr=(int *)malloc(sizeof(int)*n);
    int ans1,ans2;
    for(i=0;i<n;i++){
        arr[i]=rand();
    }
    s1=clock();
    ans1=bs(arr,0,n-1,k);
    e1=clock();
    s2=clock();
    ans2=tsearch(arr,0,n-1,k);
    e2=clock();
    for(i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    printf("\n");
    printf("%d\n%f\n%f\n",ans1,((double)(e1-s1)/CLOCKS_PER_SEC),((double)(e2-s2)/CLOCKS_PER_SEC));
    return 0;
}
