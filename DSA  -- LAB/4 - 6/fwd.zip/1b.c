#include <stdio.h>
#include <string.h>
int main()
{
	long n,i,j;
	scanf("%ld",&n);
	getchar();
	typedef struct Book
	{
		char author[5];
		int edition;
		int isbn;
		int price;
		char pntn[5];
		int year;
	}Book;
	Book req[n],swap;
	for(i=0;i<n;i++)
	{
		scanf("%s",req[i].author);
		scanf("%d",&req[i].edition);
		scanf("%d",&req[i].isbn);
		scanf("%d",&req[i].price);
		scanf("%s",req[i].pntn);
		scanf("%d",&req[i].year);
		getchar();
		getchar();
		
	}
	for(i=1;i<n;i++)
	{
		for(j=i;j>0;j--)
		{
			if(req[j].year<req[j-1].year)
			{
				{
					strcpy(swap.author,req[j].author);
					swap.edition=req[j].edition;
					swap.isbn=req[j].isbn;
					swap.price=req[j].price;
					strcpy(swap.pntn,req[j].pntn);
					swap.year=req[j].year;
				}
				{
					strcpy(req[j].author,req[j-1].author);
					req[j].edition=req[j-1].edition;
					req[j].isbn=req[j-1].isbn;
					req[j].price=req[j-1].price;
					strcpy(req[j].pntn,req[j-1].pntn);
					req[j].year=req[j-1].year;
				}
				{
					strcpy(req[j-1].author,swap.author);
					req[j-1].edition=swap.edition;
					req[j-1].isbn=swap.isbn;
					req[j-1].price=swap.price;
					strcpy(req[j-1].pntn,swap.pntn);
					req[j-1].year=swap.year;
				}
			}
			else
				break;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%s\n",req[i].author);
		printf("%d\n",req[i].edition);
		printf("%d\n",req[i].isbn);
		printf("%d\n",req[i].price);
		printf("%s\n",req[i].pntn);
		printf("%d\n",req[i].year);
		printf("\n\n");
	}
	return 0;
}