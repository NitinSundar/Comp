#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
	long n;
	scanf("%ld",&n);
	typedef struct Book
	{
		char author[5];
		int edition;
		int isbn;
		int price;
		char pntn[5];
		int year;
	}Book;
	Book req[n];
	long i,j;
	time_t t;
	srand((unsigned) time(&t));
	for(i=0;i<n;i++)
	{
		for(j=0;j<5;j++)
		{
			req[i].author[j]=(char)((rand()%26)+65);
		}
		req[i].edition=(rand()%10)+1;
		req[i].isbn=(rand()%10)+1;
		req[i].price=(rand()%1000)+1;
		for(j=0;j<5;j++)
		{
			req[i].pntn[j]=(char)((rand()%26)+65);
		}
		req[i].year=(rand()%20000)+1;
	}
	printf("%ld\n\n",n);
	for(i=0;i<n;i++)
	{
		printf("%s\n",req[i].author);
		printf("%d\n",req[i].edition);
		printf("%d\n",req[i].isbn);
		printf("%d\n",req[i].price);
		printf("%s\n",req[i].pntn);
		printf("%d\n",req[i].year);
		printf("\n\n");
	}
	return 0;
}