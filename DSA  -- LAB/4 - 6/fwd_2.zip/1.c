#include <stdio.h>
#include <time.h>
typedef struct Book{
    char b_name[100];
    char author[100];
    int edition;
    int isbn_no;
    int price;
    char publication[100];
    int p_year;
}book;
void swap(book* a,book* b)
{
    book temp=*a;
    *a=*b;
    *b=temp;
}
void iSortPrice(book arr[], int len){
    int i, j;
    book temp;
    for(i = 1; i < len; i++){
        j = i;
        while((j > 0) && (arr[j].price < arr[j - 1].price)){
            swap(&arr[j],&arr[j-1]);
            j--;
        }
    }
}
/*void iSortYear(book arr[], int len){
    int i, j;
    struct Book temp;
    for(i = 1; i < len; i++){
        j = i;
        while((j > 0) && (arr[j].p_year < arr[j - 1].p_year)){
            temp = arr[j];
            arr[j] = arr[j - 1];
            arr[j - 1] = temp;
            j--;
        }
    }
}*/

void iSortYear(book a[],int len)
{
    int i,j,k;
    book temp;
    for(i=1;i<len;i++)
    {
        j=i;
        for(j=0;j<i;j++)
        {

            if(a[i].p_year>a[j].p_year)
                swap(&a[i],&a[j]);
        }
    }
}
int main(void) {
	int i, r, n;
	FILE *fp;
	scanf("%d", &n);
	book arr[n];
	srand(time(NULL));
	fp = fopen("price.txt", "w");
	for(i = 0; i < n; i++){
		r = rand();
		fprintf(fp, "%d ", r);
	}
	fclose(fp);
	fp = fopen("year.txt", "w");
	for(i = 0; i < n; i++){
        r = rand()%2017;
        fprintf(fp, "%d ", r);
	}
	fclose(fp);
	fp = fopen("price.txt", "r");
	for(i = 0; i < n; i++){
        fscanf(fp, "%d", &r);
        arr[i].price = r;
	}
	fclose(fp);
	fp = fopen("year.txt", "r");
	for(i = 0; i < n; i++){
        fscanf(fp, "%d", &r);
        arr[i].p_year = r;
	}
	fclose(fp);
	iSortPrice(arr, n);
	printf("Sorting by price :-\n");
	for(i = 0; i < n; i++){
        printf("price = %d, p_year = %d\n", arr[i].price, arr[i].p_year);
	}
	printf("\nSorting by year :-\n");
	iSortYear(arr, n);
	for(i = 0; i < n; i++){
        printf("price = %d, p_year = %d\n", arr[i].price, arr[i].p_year);
	}
	return 0;
}
